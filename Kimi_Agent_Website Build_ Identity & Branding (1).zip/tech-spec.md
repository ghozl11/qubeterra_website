# Qubeterra Institute — Technical Specification

## Dependencies

### Production

| Package | Version | Purpose |
|---|---|---|
| react | ^19.0.0 | UI framework |
| react-dom | ^19.0.0 | DOM renderer |
| react-router-dom | ^7.0.0 | Multi-page routing (Home, About, Domains, Fellowships, Consultancy, Contact) |
| three | ^0.172.0 | Orbital rings canvas (WebGL) |
| gsap | ^3.12.0 | Animation engine, ScrollTrigger, SplitText |
| lenis | ^1.2.0 | Smooth scroll with inertia |
| lucide-react | ^0.460.0 | Outline icons (hexagon, orbit, globe, brain, server, etc.) |

### Development

| Package | Version | Purpose |
|---|---|---|
| vite | ^6.0.0 | Build tool |
| @vitejs/plugin-react | ^4.0.0 | React fast-refresh for Vite |
| tailwindcss | ^4.0.0 | Utility-first CSS |
| @tailwindcss/vite | ^4.0.0 | Tailwind Vite integration |
| typescript | ^5.7.0 | Type checking |
| @types/react | ^19.0.0 | React type definitions |
| @types/react-dom | ^19.0.0 | ReactDOM type definitions |
| @types/three | ^0.172.0 | Three.js type definitions |

---

## Component Inventory

### Layout (shared across pages)

| Component | Source | Notes |
|---|---|---|
| Navigation | Custom | Fixed header, scroll-aware background, mobile hamburger overlay. Logo + 5 nav links + CTA. |
| Footer | Custom | 3-row footer: link columns + partner badges + copyright. |
| PageLayout | Custom | Wraps Navigation + Footer around page content. Provides Lenis scroll context. |

### Sections — Home

| Component | Notes |
|---|---|
| HomeHero | Full-viewport hero with Earth background, orbital rings canvas visible behind. SplitText character reveal on headline. Scroll indicator. |
| AboutSnapshot | Two-column: text left + command center image right. Glass quote card. |
| ServicesGrid | Header + 3-column card grid. Each card is a GlassCard with colored top accent. |
| DomainsOverview | 5 stacked domain rows with alternating image/text layout. |
| FellowshipPreview | Two-column: text + program cards left, lab image right. |
| Impact | Stats counter row + SVG world map with pulsing city dots. Radial gradient background. |
| ThinkTankPreview | Two-column: strategy image left, text + pill tags right. |
| PartnerTicker | CSS-only infinite scroll ticker of partner names. |
| CTABanner | Large glass card with centered manifesto text + dual CTAs. |

### Sections — About

| Component | Notes |
|---|---|
| AboutHero | 70vh hero with hardware background. |
| VisionMission | Two-column: vision/mission text left, 2×3 values grid right. |
| BrandManifesto | Centered quote with decorative line. Faint world map grid background. |
| OurStory | Single-column narrative with 3 paragraphs. |

### Sections — Domains

| Component | Notes |
|---|---|
| DomainsHero | 70vh hero. |
| DomainCards | 5 full-width alternating-layout cards (image left/right). Each has pill tags. |

### Sections — Fellowships

| Component | Notes |
|---|---|
| FellowshipsHero | 70vh hero. |
| FellowshipOverview | Centered text + horizontal 4-step timeline (circles + connecting line). |
| ProgramDetails | 2 stacked program cards with curriculum phases/lists. |
| FellowshipCTA | Centered heading + dual CTAs. |

### Sections — Consultancy

| Component | Notes |
|---|---|
| ConsultancyHero | 70vh hero. |
| ConsultancyServices | 2×2 grid of service cards with colored top accents. |
| ConsultancyApproach | Two-column: text + numbered process list left, research image right. |
| ConsultancyCTA | Glass card CTA section. |

### Sections — Contact

| Component | Notes |
|---|---|
| ContactHero | 50vh hero (shorter, minimal — just orbital rings). |
| ContactForms | Two side-by-side glass card forms (fellowship application + partnership inquiry). |
| DirectContact | 3-column grid of contact info cards. |

### Reusable Components

| Component | Used By | Notes |
|---|---|---|
| GlassCard | ~20 instances across all pages | Glass surface (backdrop-filter, thin border, 12px radius). Accepts `accentColor` prop for optional top border accent. Hover state brightens border/background. |
| SectionLabel | Every section | IBM Plex Mono label with em-dash prefix and Quantum Blue color. |
| PrimaryButton | ~10 instances | Quantum Blue fill button. Hover: lighten + glow shadow. |
| SecondaryButton | ~8 instances | Transparent with border. Hover: brighter border + subtle bg. |
| ScrollReveal | All non-hero sections | Wrapper that applies GSAP ScrollTrigger entrance animation. Accepts `pattern` (A/B/C/D) and `delay` props. |
| StatCounter | Impact section | Scroll-triggered number count-up using GSAP. |
| OrbitalCanvas | Global (fixed behind all pages) | Three.js canvas with 5 concentric torus rings + UnrealBloomPass. Runs once, persists across page navigations. |

---

## Animation Implementation

| Animation | Library | Approach | Complexity |
|---|---|---|---|
| Orbital rings (5 torus rings, rotating, orbiting camera, bloom) | Three.js + postprocessing | OrthographicCamera, TorusGeometry ×5, MeshStandardMaterial with emissive, UnrealBloomPass. rAF loop. Mobile: scale 0.6, bloom 0.4. | **High** 🔒 |
| Hero headline character reveal | GSAP + SplitText | SplitText splits H1 into chars. GSAP stagger: opacity 0→1, y 60→0, 0.02s stagger, power3.out. Fires on mount (not scroll). | **Medium** |
| Scroll-triggered fade-up (Pattern A) | GSAP ScrollTrigger | ScrollReveal wrapper. opacity 0→1, y 30→0, 0.8s, power3.out, start: "top 85%". | Low |
| Stagger fade-up (Pattern B) | GSAP ScrollTrigger | Same as A but with stagger: 0.15s. Applied to card grids, domain rows. | Low |
| Scale-in (Pattern C) | GSAP ScrollTrigger | opacity 0→1, scale 0.95→1.0, 1.0s, power2.out. For featured images and CTA banner. | Low |
| Stat counter | GSAP ScrollTrigger | ScrollTrigger fires once at "top 85%". GSAP tweens a proxy object from 0 to target over 2.5s, power2.out. onUpdate writes Math.round(value) to DOM. | Low |
| Nav background transition | CSS transition | Scroll listener toggles class at 100px scroll. CSS handles background/border fade over 0.4s. | Low |
| Mobile menu overlay | CSS transition | Full-screen overlay. Open: fade + scale(0.98→1.0), 0.4s. Close: reverse. | Low |
| Partner logo ticker | CSS @keyframes | Two duplicate rows, translateX(0→-50%), 30s linear infinite. pause on hover. No JS. | Low |
| World map pulsing dots | CSS @keyframes | scale 1→1.5→1, opacity pulse, 2s infinite. Pure CSS. | Low |
| Scroll indicator | CSS @keyframes | Small circle translates down a vertical line, 2s ease-in-out infinite. Fades out via scroll listener at 200px. | Low |
| Page transitions | CSS transition | React Router route change triggers opacity fade (0→1), 0.3s. | Low |
| Fellowship timeline | CSS + SVG | 4 circles connected by SVG line. Responsive: horizontal on desktop, vertical on mobile. No animation needed — static layout. | Low |

---

## State & Logic Plan

### OrbitalCanvas — cross-page persistence

The Three.js canvas is a single instance mounted at the app root level (outside React Router's outlet), with `position: fixed; z-index: 0; pointer-events: none`. It must NOT unmount/remount on page navigations. On mobile (<768px), ring radii scale by 0.6 and bloom strength drops to 0.4 — detected via `window.innerWidth` on mount and resize. Animation pauses when `document.hidden` is true (visibilitychange API).

### Lenis ↔ GSAP ScrollTrigger bridge

Lenis owns the scroll. On every Lenis scroll event, call `ScrollTrigger.update()`. This is initialized once in PageLayout and shared across all pages. Lenis instance must be destroyed and recreated on page navigation to reset scroll position.

### ScrollReveal — pattern coordination

Each ScrollReveal component registers its own GSAP ScrollTrigger. Pattern D (SplitText) is only used for HomeHero headline — it fires on mount with a timeline, not on scroll. All other patterns (A, B, C) use scroll-triggered animations. Components accept `pattern`, `delay`, and `stagger` props.

### StatCounter — value proxy

Stats use a ref-based approach: GSAP tweens `{ value: 0 }` to `{ value: target }`. In `onUpdate`, the ref's innerText is set to `Math.round(obj.value)`. The counter fires once via ScrollTrigger `once: true`.

---

## Other Key Decisions

### Routing
React Router v7 with `BrowserRouter`. 6 routes: `/` (Home), `/about`, `/domains`, `/fellowships`, `/consultancy`, `/contact`. Page transitions handled by a wrapper component that applies CSS fade on route change.

### Three.js post-processing
Use `three/examples/jsm/postprocessing/UnrealBloomPass` for the neon glow on orbital rings. This requires the EffectComposer pipeline: RenderPass → UnrealBloomPass. The page background (`#05070A`) shows through because the renderer uses `alpha: true`.

### Image treatment
All photographic images receive a consistent CSS filter via a utility class: `saturate-[0.85] contrast-[1.05]` — applies the brand's cool-tone, slightly desaturated look. No per-image JavaScript processing needed.

### Form handling
Contact forms are presentational (no backend). On submit, show a success state (button text changes to "Submitted" with a check icon). No actual API calls. This is explicitly a frontend-only build.
